#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/c/cibw/vendor/lib"
XML2_LIBS="-lxml2 -lz -L/c/cibw/vendor/lib -llzma    -liconv   "
XML2_INCLUDEDIR="-I/c/cibw/vendor/include/libxml2"
MODULE_VERSION="xml2-2.9.13"

